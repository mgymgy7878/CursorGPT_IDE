"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

type Saved = { ts:number; prompt:string; result:any };

export default function Strategies() {
  const [list, setList] = useState<Saved[]>([]);
  const [msg, setMsg] = useState("-");
  const router = useRouter();

  const load = ()=> setList(JSON.parse(localStorage.getItem("lab.strats")||"[]"));
  useEffect(()=>{ load(); }, []);

  const del = (i:number)=>{ const n=[...list]; n.splice(i,1); localStorage.setItem("lab.strats", JSON.stringify(n)); setList(n); };
  const copy = (s:Saved)=> navigator.clipboard.writeText(JSON.stringify(s.result, null, 2));
  const start = async(s:Saved)=>{
    const r = await fetch("/api/strategy/run", {method:"POST", body: JSON.stringify({ label:"lab", code:s.result?.code, dryRun:true, riskGuard:true })});
    const j = await r.json().catch(()=>({error:true}));
    setMsg(JSON.stringify(j));
  };

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Stratejilerim</h1>
      <div className="card p-6">
        {list.length===0 && <div className="muted">Henüz kayıt yok.</div>}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {list.map((s, i)=>(
            <div key={i} className="card p-4">
              <div className="text-xs muted mb-2">{new Date(s.ts).toLocaleString()}</div>
              <div className="whitespace-pre-wrap mb-4 text-sm">{s.prompt}</div>
              <div className="flex flex-wrap gap-2">
                <button className="btn">Düzenle</button>
                <button className="btn">Optimize Et</button>
                <button className="btn">Backtest</button>
                <button className="btn-primary">Çalıştır</button>
                <button className="btn-danger">Sil</button>
              </div>
            </div>
          ))}
        </div>
      </div>
      <pre className="mt-6 card p-4 overflow-auto text-sm">{msg}</pre>
    </div>
  );
}