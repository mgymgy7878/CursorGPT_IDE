import { Counter, Gauge, Registry, collectDefaultMetrics, Summary } from 'prom-client';

// Singleton registry to avoid duplicate collectors on hot reloads / multi-import
const REG_KEY = Symbol.for('spark.metrics.registry');
const g: any = globalThis as any;
if (!g[REG_KEY]) g[REG_KEY] = new Registry();
export const register: Registry = g[REG_KEY];

if (!g.__sparkDefaultMetricsBound) {
  collectDefaultMetrics({ register, prefix: 'executor_' });
  g.__sparkDefaultMetricsBound = true;
}

export const execStartTotal = new Counter({
  name: 'exec_start_total',
  help: 'Number of strategy start requests',
  registers: [register],
});

export const execStopTotal = new Counter({
  name: 'exec_stop_total',
  help: 'Number of strategy stop requests',
  registers: [register],
});

export const activeStrategies = new Gauge({
  name: 'active_strategies',
  help: 'Current active strategy count',
  registers: [register],
});

// NEW: generic HTTP & rate-limit metrics
export const httpRequestsTotal = new Counter({
  name: 'http_requests_total',
  help: 'HTTP requests labeled with method, route and code',
  labelNames: ['method', 'route', 'code'] as const,
  registers: [register],
});

export const rateLimitHitsTotal = new Counter({
  name: 'rate_limit_hits_total',
  help: 'Total requests blocked by rate limit, labeled by route',
  labelNames: ['route'] as const,
  registers: [register],
});

// Futures confirm & UDS metrics
export const futuresOrdersBlockedTotal = new Counter({
  name: 'futures_orders_blocked_total',
  help: 'Futures orders blocked by guard, labeled by reason',
  labelNames: ['reason'] as const,
  registers: [register],
});

export const futuresUdsLifecycleTotal = new Counter({
  name: 'futures_uds_lifecycle_total',
  help: 'UserDataStream lifecycle ops total, labeled by action and status',
  labelNames: ['action','status'] as const,
  registers: [register],
});

export const futuresUdsLastKeepaliveTs = new Gauge({
  name: 'futures_uds_last_keepalive_ts',
  help: 'Last keepalive timestamp (epoch ms)',
  registers: [register],
});

// Optimize metrics
export const optimizeRunsTotal = new Counter({
  name: 'optimize_runs_total',
  help: 'Optimize runs',
  registers: [register],
});

export const optimizeErrorsTotal = new Counter({
  name: 'optimize_errors_total',
  help: 'Optimize errors',
  registers: [register],
});

export const optimizeLatencyMsSummary = new Counter({
  name: 'optimize_latency_ms_total',
  help: 'Cumulative optimize latency ms (use with rate for avg)',
  registers: [register],
});

// --- New: AI Generate metrics (central registry) ---
export const aiGenerateTotal = new Counter({
  name: 'ai_generate_total',
  help: 'AI strategy generate calls',
  labelNames: ['provider', 'risk'] as const,
  registers: [register],
});

export const aiTokensTotal = new Counter({
  name: 'ai_tokens_total',
  help: 'Estimated tokens used by AI',
  registers: [register],
});

export const aiLatencyMs = new Summary({
  name: 'ai_latency_ms',
  help: 'AI generate latency (ms)',
  registers: [register],
});
