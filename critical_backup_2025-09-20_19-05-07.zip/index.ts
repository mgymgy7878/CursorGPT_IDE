import './bootstrap/env';
import { installCrashGuard } from './bootstrap/crash-guard';
installCrashGuard();
import Fastify from 'fastify';
import { ENV } from './env';
// import cors from '@fastify/cors';
import websocket from '@fastify/websocket';
import { startStrategy, pauseStrategy, stopStrategy, listStrategies, onChange } from './state/strategies.js';
import rateLimit from '@fastify/rate-limit';
import { writeTextFile } from './lib/fs-helpers.js';

// Safe plugin registration helper
async function safeRegister<T extends (...args:any)=>any>(fn:()=>Promise<T>|T, log:any, label:string) {
  try { 
    await fn() 
  } catch (err:any) {
    if (err?.code === 'FST_ERR_PLUGIN_VERSION_MISMATCH') {
      log?.warn({ err, label }, `${label} disabled due to Fastify version mismatch`)
    } else { 
      throw err 
    }
  }
}
import { register, execStartTotal, execStopTotal, activeStrategies } from './metrics.js';
import os from 'node:os';
import httpMetricsPlugin from './plugins/httpMetrics.js';
import auditRoutes from './routes/public/audit.js';
import strategyLiveRoutes from './routes/strategy-live.js';

// V1.2 Market Data Adapters (commented out due to ESM issues)
// import { createBTCTurkClient } from '@spark/marketdata';
// import { createBISTReader } from '@spark/bist-reader';
// import binanceTestRoute from './routes/test/binance.js'; // may import undici
// import btcturkTestRoute from './routes/test/btcturk.js';
import futuresRoutes from './routes/futures.js';
import positionsRoutes from './routes/positions.js';
import copilotRoutes from './routes/copilot.js';
import backtestRoutes from './routes/backtest.js';
import optimizeRoutes from './routes/optimize.js';
import healthPlugin from './plugins/health.js';
import { log as auditLog } from './utils/audit.js';
import typeProvider from './plugins/type-provider.js';
// import { placeRoutes } from './routes/place.js'; // Disabled: depends on @spark/exchange-btcturk missing export
import { feedRoutes } from './routes/feed.js';
import btcturkRoutes from './routes/btcturk.js';
import { guardrails } from './guardrails.js';
import { execRoutes } from './routes/exec.js';
import aiRoutes from './routes/ai-generate.js';
import rlPlugin from './plugins/ratelimit.js';
import alertsRoutes from './routes/alerts.js';
import strategyRoutes from './routes/strategy.js';

const app = Fastify({ logger: true });

// Global error handler
app.setErrorHandler((err, _req, reply) => {
  app.log.error({ err }, 'unhandled');
  if (!reply.sent) reply.code(500).send({ ok: false, error: err.message });
});

app.get('/health', async () => ({ ok: true, ts: Date.now(), host: os.hostname(), mode: 'NORMAL' }));

// ENV kanıt logu
app.log.info({
  cwd: process.cwd(),
  env_loaded: !!process.env.BINANCE_FUTURES_BASE_URL,
  base_url: process.env.BINANCE_FUTURES_BASE_URL,
  prefix: process.env.BINANCE_FUTURES_PREFIX
}, 'startup-env');

process.on('unhandledRejection', (e) => app.log.error({ err: e }, 'UNHANDLED_REJECTION'));
process.on('uncaughtException', (e) => { app.log.error({ err: e }, 'UNCAUGHT_EXCEPTION'); process.exit(1); });

const HOST = process.env.HOST ?? '0.0.0.0';
const PORT = Number(process.env.PORT ?? 4001);

async function start() {
  app.log.info({ HOST, PORT, pid: process.pid, node: process.version }, 'boot');
  await app.register(typeProvider);
  await app.register(httpMetricsPlugin);
  await app.register(rlPlugin);
  // await app.register(cors, { origin: true } as any); // Disabled due to version mismatch; enable later
  await app.register(healthPlugin);
  
  // Rate limit plugin - guard ile koru
  if (process.env.EXEC_RATE_LIMIT_DISABLED !== '1') {
    await safeRegister(() =>
      app.register(rateLimit, {
        max: Number(process.env.NODE_ENV === 'production' ? (process.env.RATE_LIMIT_PER_MIN_PROD ?? 5) : (process.env.RATE_LIMIT_PER_MIN_DEV ?? 20)),
        timeWindow: '1 minute'
      }),
      app.log, '@fastify/rate-limit'
    );
  } else {
    app.log.info('Rate limit disabled via EXEC_RATE_LIMIT_DISABLED env var');
  }
  
  // WebSocket plugin - guard ile koru
  if (process.env.EXEC_WS_DISABLED !== '1') {
    await safeRegister(() =>
      app.register(websocket),
      app.log, '@fastify/websocket'
    );
  } else {
    app.log.info('WebSocket disabled via EXEC_WS_DISABLED env var');
  }
  
  // Register new routes
  // await app.register(placeRoutes); // Disabled to unblock build
  await app.register(feedRoutes);
  await app.register(btcturkRoutes);
  await app.register(auditRoutes);
  // await app.register(binanceTestRoute);
  // await app.register(btcturkTestRoute);
  await app.register(futuresRoutes, { prefix: '/api/futures' } as any);
  await app.register(positionsRoutes as any);
  await app.register(copilotRoutes, { prefix: '/api' } as any);
  await app.register(backtestRoutes, { prefix: '/api' } as any);
  await app.register(optimizeRoutes, { prefix: '/api' } as any);
  await app.register(aiRoutes);
  await app.register(alertsRoutes);
  await app.register(strategyRoutes);
  await app.register(strategyLiveRoutes);
  
  // Register canary routes with flag protection
  const CANARY_ENABLED = process.env.CANARY_ENABLED === 'true';
  
  if (CANARY_ENABLED) {
    try {
      const canaryLivePlan = await import('./routes/canary-live-plan.js');
      await app.register(canaryLivePlan.default, { prefix: '/api' } as any);
      app.log.info('canary routes registered');
    } catch (err: any) {
      app.log.warn({ err }, 'canary route registration failed - skipping');
    }
  } else {
    app.log.info('canary disabled by flag');
  }
  
  // Fallback: ensure critical futures endpoints exist even if plugin registration fails
  try {
    app.get('/api/futures/time', async (_req, reply) => {
      try {
        const { makeFuturesFromEnv } = await import('./lib/binance-futures.js');
        const fut = makeFuturesFromEnv();
        const r = await fut.time();
        reply.send(r as any);
      } catch (err:any) {
        reply.code(500).send({ error:'futures_time_failed', message: err?.message || String(err) });
      }
    });
    app.get('/api/futures/klines', async (req:any, reply:any) => {
      try {
        const { makeFuturesFromEnv } = await import('./lib/binance-futures.js');
        const fut = makeFuturesFromEnv();
        const { symbol, interval, limit, startTime, endTime } = (req.query ?? {}) as any;
        const r = await fut.klines({ symbol, interval, limit: limit?Number(limit):undefined, startTime:startTime?Number(startTime):undefined, endTime:endTime?Number(endTime):undefined } as any);
        reply.send(r as any);
      } catch (err:any) {
        reply.code(500).send({ error:'futures_klines_failed', message: err?.message || String(err) });
      }
    });
  } catch {}

  // Canary dry-run stub (testnet demonstration, no live trading)
  app.post('/api/canary/run', async (req:any, reply:any) => {
    try {
      const payload = (req.body ?? {}) as any;
      return reply.code(200).send({ ok: true, dryRun: true, echo: payload, ts: Date.now() });
    } catch (err:any) {
      return reply.code(500).send({ ok:false, error:'canary_failed', message: err?.message || String(err) });
    }
  });

  // Fallback: backtest job routes (POST→jobId, GET stream, DELETE cancel)
  try {
    app.post('/api/backtest/jobs', async (req:any, reply:any) => {
      const body = (req.body ?? {}) as any;
      const { createJob, setJobState, setJobOutput, setJobError, emitJobEvent } = await import('./lib/jobs.js');
      const { runBacktestCore } = await import('./lib/backtest-core.js');
      const job = createJob('backtest', body);
      setJobState(job.id, 'running');
      (async () => {
        try {
          const result = await runBacktestCore({ ...body, onEvent: (ev:any) => emitJobEvent(job.id, ev) });
          setJobOutput(job.id, result);
          setJobState(job.id, 'done');
          emitJobEvent(job.id, { event: 'done', result });
          try {
            await writeTextFile(`evidence/local/backtest/${job.id}.metrics.json`, JSON.stringify(result.metrics, null, 2));
            if (Array.isArray(result.equity)) {
              const header = 't,v\n';
              const bodyCsv = result.equity.map(([t,v]:[number,number])=>`${t},${v}`).join('\n');
              await writeTextFile(`evidence/local/backtest/${job.id}.equity.csv`, header+bodyCsv);
            }
          } catch {}
        } catch (e:any) {
          setJobError(job.id, { message: e?.message || 'backtest_failed' });
          emitJobEvent(job.id, { event: 'error', message: e?.message || 'backtest_failed' });
        }
      })();
      return reply.send({ ok: true, jobId: job.id, state: 'running' });
    });

    app.get('/api/backtest/stream/:jobId', async (req:any, reply:any) => {
      const { jobId } = req.params as any;
      const { getJob, onJobEvent, offJobEvent } = await import('./lib/jobs.js');
      const job = getJob(jobId);
      if (!job) return reply.code(404).send({ ok:false, error:'job_not_found' });
      reply.raw.writeHead(200, { 'Content-Type':'text/event-stream', 'Cache-Control':'no-cache', Connection:'keep-alive' });
      const handler = (ev:any)=> reply.raw.write(`data: ${JSON.stringify(ev)}\n\n`);
      onJobEvent(jobId, handler);
      reply.raw.write(`data: ${JSON.stringify({ event:'attached', state: job.state })}\n\n`);
      req.raw.on('close', ()=> offJobEvent(jobId, handler));
    });

    app.delete('/api/backtest/jobs/:jobId', async (req:any, reply:any) => {
      const { jobId } = req.params as any;
      const { cancelJob } = await import('./lib/jobs.js');
      return reply.send({ ok: cancelJob(jobId) });
    });
  } catch {}
  // await app.register(execRoutes); // Duplicate route sorunu nedeniyle kapatıldı
  // Portfolio routes (mock)
  try {
    const { portfolioRoutes } = await import('./routes/portfolio.js');
    await app.register(portfolioRoutes);
  } catch {}
  
  // Guardrails status endpoint
  app.get('/guardrails/status', async () => guardrails.getStatus());
  // healthPlugin already provides /public/health and /api/public/live/health
  app.get('/public/metrics/prom', async (_req, res) => { res.header('Content-Type', register.contentType); res.send(await register.metrics()); });

  // Basit WS yayın (demo): /ws/strategies - sadece WebSocket aktifse
  if (!process.env.EXEC_WS_DISABLED) {
    app.get('/ws/strategies', { websocket: true }, (conn /*, req*/) => {
      const send = (obj: unknown) => conn.socket.readyState === 1 && conn.socket.send(JSON.stringify(obj));
      // snapshot
      send({ type: 'snapshot', rows: listStrategies() });
      // delta
      const off = onChange((row) => send({ type: 'delta', row }));
      conn.socket.on('close', () => off());
    });
  }

  // Exec lifecycle REST
  function authGuard(req:any, res:any, done:any){
    const token = process.env.EXEC_API_TOKEN;
    if (!token) return done();
    const h = (req.headers?.authorization as string) || '';
    if (h === `Bearer ${token}`) return done();
    res.code(401).send({ ok:false, msg:'unauthorized' });
  }

  app.post('/exec/start', { preHandler: authGuard }, async (req, res) => {
    const body = (req.body ?? {}) as any;
    const id = body?.id; if (!id) return res.code(400).send({ ok: false, msg: 'id required' });
    const out = startStrategy(id, body?.name);
    execStartTotal.inc(); activeStrategies.set(listStrategies().filter(x=>x.status==='running').length);
    try { auditLog({ ts: Date.now(), type: 'exec_start', details: { id }, actor: (req as any).user?.id }); } catch {}
    return res.send(out);
  });
  app.post('/exec/pause', { preHandler: authGuard }, async (req, res) => {
    const id = (req.body as any)?.id; if (!id) return res.code(400).send({ ok: false, msg: 'id required' });
    const out = pauseStrategy(id);
    activeStrategies.set(listStrategies().filter(x=>x.status==='running').length);
    try { auditLog({ ts: Date.now(), type: 'exec_pause', details: { id }, actor: (req as any).user?.id }); } catch {}
    return res.send(out);
  });
  app.post('/exec/stop', { preHandler: authGuard }, async (req, res) => {
    const id = (req.body as any)?.id; if (!id) return res.code(400).send({ ok: false, msg: 'id required' });
    const out = stopStrategy(id);
    execStopTotal.inc(); activeStrategies.set(listStrategies().filter(x=>x.status==='running').length);
    try { auditLog({ ts: Date.now(), type: 'exec_stop', details: { id }, actor: (req as any).user?.id }); } catch {}
    return res.send(out);
  });
  app.get('/exec/list', async (_req, res) => res.send({ rows: listStrategies() }));
  
  await app.listen({ host: HOST, port: PORT });
  app.log.info({ HOST, PORT }, 'listening');
  
  // V1.2 Market Data Adapters Startup (commented out due to ESM issues)
  // try {
  //   // BTCTurk Client
  //   const btcturkClient = createBTCTurkClient({
  //     symbols: ['BTCUSDT', 'ETHUSDT'],
  //     registry: register,
  //     log: app.log
  //   });
  //   await btcturkClient.connect();
  //   app.log.info('BTCTurk client connected');
  //   
  //   // BIST Reader
  //   const bistReader = createBISTReader({
  //     symbols: ['THYAO', 'AKBNK', 'GARAN'],
  //     registry: register,
  //     log: app.log
  //   });
  //   bistReader.start();
  //   app.log.info('BIST reader started');
  //   
  // } catch (err: any) {
  //   app.log.warn({ err }, 'V1.2 market data adapters startup failed - continuing without');
  // }
  
  // Graceful shutdown handlers
  for (const sig of ['SIGINT','SIGTERM'] as const) {
    process.on(sig, async () => {
      app.log.warn({ sig }, 'graceful shutdown');
      try { await app.close(); } finally { process.exit(0); }
    });
  }
}

start().catch((err) => { 
  app.log.error({ err }, 'FASTIFY_LISTEN_FAILED'); 
  process.exit(1); 
});
