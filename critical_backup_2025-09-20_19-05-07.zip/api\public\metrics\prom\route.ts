export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  const origin = process.env.EXECUTOR_ORIGIN || 'http://127.0.0.1:4001';
  const res = await fetch(`${origin}/public/metrics/prom`, { cache: 'no-store' });
  const text = await res.text();
  const rescue = process.env.RESCUE_ENABLED === '1' ? 1 : 0;
  const extra =
    '\n# HELP web_next_rescue_enabled Rescue modu (0 kapalı, 1 açık)\n' +
    '# TYPE web_next_rescue_enabled gauge\n' +
    `web_next_rescue_enabled{app="web-next"} ${rescue}\n`;
  return new Response(text + extra, {
    status: res.status,
    headers: { 'content-type': res.headers.get('content-type') ?? 'text/plain; version=0.0.4; charset=utf-8' }
  });
}
