"use client";

import RunningStrategies from "./_parts/RunningStrategies";
import PortfolioSummary from "./_parts/PortfolioSummary";

export default function Home() {
  return (
    <div className="mx-auto max-w-6xl px-4 pb-16">
      <h1 className="text-2xl font-bold mb-6">Ana Sayfa</h1>

      <section className="mb-8">
        <h2 className="text-lg font-semibold mb-3">Çalışan Stratejiler</h2>
        <RunningStrategies />
      </section>

      <section>
        <h2 className="text-lg font-semibold mb-3">Portföy Yönetimi</h2>
        <PortfolioSummary />
      </section>
    </div>
  );
}