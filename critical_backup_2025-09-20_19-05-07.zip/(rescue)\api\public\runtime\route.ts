export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  const origin = process.env.EXECUTOR_ORIGIN || 'http://127.0.0.1:4001';
  let ping: any;
  try {
    const r = await fetch(`${origin}/health`, { cache: 'no-store' });
    ping = { ok: r.ok, status: r.status };
  } catch (e: any) {
    ping = { ok: false, error: String(e?.message ?? e) };
  }
  return new Response(JSON.stringify({
    node: process.version,
    executorOrigin: origin,
    ping
  }), { status: 200, headers: { 'content-type': 'application/json' } });
}
