import "./globals.css";
import Link from "next/link";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="tr" className="h-full">
      <body className="h-full bg-neutral-950 text-neutral-100 antialiased overflow-hidden">
        {/* HER SAYFADA NAVBAR */}
        <header className="fixed top-0 inset-x-0 z-50 h-[var(--nav-h)] bg-neutral-950/90 backdrop-blur border-b border-neutral-800">
          <nav className="mx-auto max-w-6xl px-4 h-full flex items-center gap-2">
            <Link href="/" className="navlink">Spark</Link>
            <Link href="/ops" className="navlink">OPS</Link>
            <Link href="/lab" className="navlink">AI Editör</Link>
            <Link href="/strategies" className="navlink">Stratejilerim</Link>
            <Link href="/settings" className="navlink">Ayarlar</Link>
            <div className="ml-auto text-xs text-emerald-400">HEALTH: GREEN</div>
          </nav>
        </header>

        {/* ARTIK FIXED DEĞİL: header yüksekliği kadar padding ver */}
        <main className="relative h-screen pt-[var(--nav-h)] overflow-hidden">
          {children}
        </main>
      </body>
    </html>
  );
}