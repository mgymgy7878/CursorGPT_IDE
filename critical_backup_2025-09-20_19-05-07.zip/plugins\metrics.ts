import fp from 'fastify-plugin';
import type { FastifyInstance } from 'fastify';
import client from 'prom-client';
import { register as registry, aiGenerateTotal, aiLatencyMs, aiTokensTotal } from '../metrics';

export const httpRequestsTotal = new client.Counter({
  name: 'spark_http_requests_total',
  help: 'HTTP requests',
  labelNames: ['route', 'method', 'status'],
  registers: [registry as any],
});

// Canary metrics used by routes/canary.ts
export const canaryArmTotal = new client.Counter({
  name: 'canary_arm_total',
  help: 'Canary arm requests',
  registers: [registry as any],
});
export const canaryConfirmTotal = new client.Counter({
  name: 'canary_confirm_total',
  help: 'Canary confirm requests',
  registers: [registry as any],
});
export const canaryFailTotal = new client.Counter({
  name: 'canary_fail_total',
  help: 'Canary failures',
  registers: [registry as any],
});
export const canaryAckMs = new client.Histogram({
  name: 'canary_ack_ms',
  help: 'Ack latency ms',
  buckets: [50,100,200,400,800,1200,2000,3000],
  registers: [registry as any],
});
export const canaryAckSummary = new client.Summary({
  name: 'canary_ack_ms_summary',
  help: 'Ack latency summary',
  percentiles: [0.5,0.9,0.95,0.99],
  registers: [registry as any],
});
export const eventToDbSummary = new client.Summary({
  name: 'event_to_db_ms_summary',
  help: 'Event to DB latency summary',
  percentiles: [0.5,0.9,0.95,0.99],
  registers: [registry as any],
});
export const clockDriftMs = new client.Gauge({
  name: 'clock_drift_ms',
  help: 'Clock drift vs exchange time',
  registers: [registry as any],
});
export const binanceFillMsSummary = new client.Summary({
  name: 'binance_fill_ms_summary',
  help: 'Binance fills latency summary',
  percentiles: [0.5,0.9,0.95,0.99],
  registers: [registry as any],
});

// AI Advisor metrics
export const advisorSuggestTotal = new client.Counter({
  name: 'advisor_suggest_total',
  help: 'AI advisor suggestion requests',
  labelNames: ['status'],
  registers: [registry as any],
});

export const advisorTokensTotal = new client.Counter({
  name: 'advisor_tokens_total',
  help: 'AI advisor token usage',
  labelNames: ['model'],
  registers: [registry as any],
});

export const advisorLatencyMs = new client.Histogram({
  name: 'advisor_latency_ms',
  help: 'AI advisor response latency',
  labelNames: ['risk'],
  buckets: [100, 200, 500, 1000, 2000, 5000],
  registers: [registry as any],
});

export const canaryPlanTotal = new client.Counter({
  name: 'canary_plan_total',
  help: 'Canary plan requests',
  labelNames: ['status'],
  registers: [registry as any],
});

export const aiToPlanMs = new client.Summary({
  name: 'ai_to_plan_ms',
  help: 'AI suggestion to plan latency',
  percentiles: [0.5, 0.9, 0.95, 0.99],
  registers: [registry as any],
});

export const planToOrderMs = new client.Summary({
  name: 'plan_to_order_ms',
  help: 'Plan to order latency',
  percentiles: [0.5, 0.9, 0.95, 0.99],
  registers: [registry as any],
});

// Convenience wrappers for metrics handlers
export const metricsText = async () => (registry as any).metrics?.() ?? client.register.metrics();
export const metricsJSON = async (): Promise<any[]> => (registry as any).getMetricsAsJSON?.() ?? [];
export const metricsContentType = (registry as any).contentType ?? client.register.contentType;

export default fp(async function metricsPlugin(fastify: FastifyInstance) {
  // Add metrics to fastify instance for route access
  (fastify as any).metrics = {
    advisorSuggestTotal,
    advisorTokensTotal,
    advisorLatencyMs,
    canaryPlanTotal,
    aiToPlanMs,
    planToOrderMs,
    aiGenerateTotal,
    aiTokensTotal,
    aiLatencyMs,
  };

  (fastify as any).addHook('onResponse', async (req: any, reply: any) => {
    try {
      (httpRequestsTotal as any).labels({
        route: req.routerPath ?? 'unknown',
        method: req.method,
        status: String(reply.statusCode),
      }).inc();
    } catch {}
  });
});