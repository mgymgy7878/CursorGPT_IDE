"use client";
import dynamic from "next/dynamic";
const Monaco = dynamic(() => import("@monaco-editor/react"), { ssr: false });

export default function LabPage() {
  return (
    // SADECE YÜKSEKLİK VE GRID: fixed/absolute YOK
    <div className="h-[calc(100vh-var(--nav-h))] min-h-0 grid grid-cols-[minmax(0,1fr)_420px] gap-4 p-4">
      {/* sol editör */}
      <div className="h-full min-h-0 grid grid-rows-[1fr_auto] rounded-2xl bg-neutral-900/40 ring-1 ring-neutral-800">
        <div className="min-h-0">
          <Monaco
            height="100%"
            defaultLanguage="typescript"
            theme="vs-dark"
            options={{
              fontSize: 16,
              lineHeight: 26,
              wordWrap: "on",
              smoothScrolling: true,
              scrollBeyondLastLine: false,
            }}
            defaultValue={`// Buraya strateji kodunu yaz veya sağdaki AI'dan üret`}
          />
        </div>
        <div className="flex items-center gap-3 p-3 border-t border-neutral-800 bg-neutral-900/60">
          <button className="btn">Backtest</button>
          <button className="btn">Optimize Et</button>
          <button className="btn btn-primary ml-auto">Kaydet</button>
        </div>
      </div>

      {/* sağ chat */}
      <div className="h-full min-h-0 grid grid-rows-[auto_1fr_auto] rounded-2xl bg-neutral-900/40 ring-1 ring-neutral-800">
        <div className="px-4 py-3 border-b border-neutral-800 font-semibold">AI Chat</div>
        <div className="overflow-auto p-4 space-y-3 text-sm">
          <div className="text-neutral-300">
            <span className="font-semibold text-neutral-100">AI: </span>
            Merhaba! "EMA 34/89 yap, ATR trailing stop ekle" gibi yaz; kodu üreteyim.
          </div>
          {/* mesajlar */}
        </div>
        <form className="flex gap-2 p-3 border-t border-neutral-800 bg-neutral-900/60">
          <input className="input flex-1" placeholder="İsteğini yaz…" />
          <button className="btn btn-primary">Gönder</button>
        </form>
      </div>
    </div>
  );
}