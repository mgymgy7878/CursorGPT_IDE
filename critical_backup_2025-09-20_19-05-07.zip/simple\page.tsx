export default function SimplePage() {
  return <div>Simple Test Page - OK</div>;
}
