export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  // Basit smoke: process versiyonları + saat
  const body = {
    ok: true,
    service: 'web-next',
    node: process.version,
    now: new Date().toISOString(),
    env: {
      EXECUTOR_ORIGIN: process.env.EXECUTOR_ORIGIN ?? null,
      NEXT_RUNTIME: process.env.NEXT_RUNTIME ?? null
    }
  };
  return new Response(JSON.stringify(body), {
    status: 200,
    headers: { 'content-type': 'application/json' }
  });
}