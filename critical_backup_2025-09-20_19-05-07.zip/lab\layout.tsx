export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="tr">
      <body style={{ margin: 0, background: '#f8fafc', fontFamily: 'Inter, system-ui, Segoe UI, Arial, sans-serif' }}>
        {/* Root Nav tüm sayfalarda görünür kalsın */}
        <div dangerouslySetInnerHTML={{__html:''}} /> 
        {children}
      </body>
    </html>
  );
}
