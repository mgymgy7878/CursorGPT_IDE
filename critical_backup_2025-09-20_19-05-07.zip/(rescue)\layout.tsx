import { notFound } from 'next/navigation';
import Nav from "../components/Nav";

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export default function RescueLayout({ children }: { children: React.ReactNode }) {
  // /ops sayfası her zaman açık, sadece /ops/rescue kilitli
  // Server-side'da path kontrolü yapamayız, bu yüzden her zaman açık
  return (
    <html lang="tr">
      <body style={{ margin: 0, fontFamily: "Inter, system-ui, Segoe UI, Arial, sans-serif" }}>
        <Nav />
        {children}
      </body>
    </html>
  );
}