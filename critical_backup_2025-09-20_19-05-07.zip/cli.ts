#!/usr/bin/env node

import { config } from "dotenv";
config();

import('./index.js'); 