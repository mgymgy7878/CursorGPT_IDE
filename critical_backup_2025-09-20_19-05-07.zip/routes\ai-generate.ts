import { FastifyInstance } from 'fastify';
import { aiGenerate } from '../ai/providers';
import { aiGenerateTotal, aiLatencyMs, aiTokensTotal } from '../metrics';
import { GenerateInput } from '../ai/schema';

export default async function aiRoutes(app: FastifyInstance) {
  app.post('/api/ai/strategies/generate', { preHandler: tokenGuard() }, async (req: any, reply: any) => {
    const t0 = Date.now();

    // Accept both legacy and new field names
    let parsed: any;
    try {
      const body = (req.body as any) || {};
      const normalized = {
        pair: body.pair || body.symbol || 'BTCUSDT',
        tf: body.tf || body.timeframe || '1h',
        style: body.style,
        risk: body.risk,
      };
      parsed = GenerateInput.parse(normalized);
    } catch (e: any) {
      (aiGenerateTotal as any).labels({ provider: 'n/a', status: '4xx', risk: 'low', fallback: 'no' }).inc();
      return reply.code(400).send({ ok:false, error:'bad_request' });
    }

    // Scope check (optional, permissive if not present)
    const scopes: string[] = (req.user?.scopes ?? []) as any;
    if (Array.isArray(scopes) && scopes.length && !scopes.includes('ai:generate')) {
      (aiGenerateTotal as any).labels({ provider: 'n/a', status: '4xx', risk: (parsed?.risk||'low'), fallback: 'no' }).inc();
      return reply.code(403).send({ ok:false, error:'forbidden' });
    }

    const providerPref = (process.env.AI_PROVIDER || 'mock').toLowerCase();

    try {
      const out = await aiGenerate({ symbol: parsed.pair, risk: (parsed.risk||'low'), timeframe: parsed.tf, provider: bodyProvider(req) } as any);
      const dt = Date.now() - t0;
      (aiLatencyMs as any).observe(dt);
      (aiGenerateTotal as any).labels({ provider: out.provider || 'n/a', status: '2xx', risk: (parsed.risk||'low'), fallback: (out.fallback?'yes':'no') }).inc();
      try {
        const tu: any = (out as any).tokenUsage;
        if (tu && typeof tu === 'object') {
          if (typeof tu.in === 'number') (aiTokensTotal as any).labels({ dir: 'in' }).inc(tu.in);
          if (typeof tu.out === 'number') (aiTokensTotal as any).labels({ dir: 'out' }).inc(tu.out);
        } else if (typeof tu === 'number') {
          (aiTokensTotal as any).labels({ dir: 'out' }).inc(tu);
        }
      } catch {}
      return reply.send({ ok:true, provider: out.provider, strategy: out.strategy });
    } catch (e: any) {
      // simple fallback to mock if openai fails
      if (providerPref === 'openai') {
        try {
          const out = await aiGenerate({ symbol: parsed.pair, risk: (parsed.risk||'low'), timeframe: parsed.tf, provider: 'mock' } as any);
          const dt = Date.now() - t0; (aiLatencyMs as any).observe(dt);
          (aiGenerateTotal as any).labels({ provider: out.provider || 'mock', status: '2xx', risk: (parsed.risk||'low'), fallback: 'yes' }).inc();
          return reply.send({ ok:true, provider: out.provider, strategy: out.strategy, fallback:true });
        } catch {}
      }
      const sc = Number(e?.statusCode || 503);
      const status = sc === 429 ? '429' : (sc >= 500 ? '5xx' : '4xx');
      (aiGenerateTotal as any).labels({ provider: providerPref || 'n/a', status, risk: (parsed?.risk||'low'), fallback: 'no' }).inc();
      return reply.code(sc || 503).send({ ok:false, error:'provider_failed' });
    }
  });

  // backward-compat passthrough
  app.post('/api/advisor/suggest', async (req, reply) => {
    const r = await app.inject({ method: 'POST', url: '/api/ai/strategies/generate', payload: req.body, headers: req.headers as any });
    reply.status(r.statusCode).headers(r.headers()).send(r.body);
  });
}

function tokenGuard() {
  const token = process.env.EXEC_API_TOKEN;
  if (!token) return async (_req:any,_res:any)=>{};
  return async (req:any, reply:any) => {
    const got = (req.headers['authorization']||'').toString().replace(/^Bearer\s+/i,'') || (req.headers['x-exec-token'] as any);
    if (got !== token) return reply.code(401).send({ ok:false, error:'unauthorized' });
  };
}

function bodyProvider(req: any): any {
  try {
    const p = (req.body as any)?.provider;
    if (p && typeof p === 'string') return p;
  } catch {}
  return undefined;
}
