import { dbLite } from "@spark/db-lite";

export const db = dbLite; 