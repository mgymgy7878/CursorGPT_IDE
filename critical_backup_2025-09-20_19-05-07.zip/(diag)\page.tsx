export const dynamic = 'force-dynamic';
export default function Page() { 
  return <pre>diag/page OK</pre>; 
}
