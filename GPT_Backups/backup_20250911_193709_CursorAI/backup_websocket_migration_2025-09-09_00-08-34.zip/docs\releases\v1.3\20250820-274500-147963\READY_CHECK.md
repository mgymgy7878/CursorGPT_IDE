# Ready Check
[ ] BINANCE_API_KEY set
[ ] BINANCE_API_SECRET set
[ ] (Optional) BIST_FEED_URL set 