#!/usr/bin/env bash
set -euo pipefail
node scripts/canary-index.mjs 