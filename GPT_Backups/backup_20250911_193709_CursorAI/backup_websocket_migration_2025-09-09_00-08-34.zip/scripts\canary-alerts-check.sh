#!/usr/bin/env bash
set -euo pipefail
node scripts/canary-alerts-check.mjs 