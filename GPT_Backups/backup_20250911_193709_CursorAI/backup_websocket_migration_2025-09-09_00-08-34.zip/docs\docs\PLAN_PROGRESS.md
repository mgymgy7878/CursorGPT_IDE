﻿# Plan Ä°lerleme KaydÄ±


## 2025-08-09 17:22:15Z
- Build: skipped
- Commit: c3da874
- Tag: manual
- Changes:
 M components/AIChatPanel.tsx
 M components/Sidebar.tsx
 M components/StrategyAI.tsx
 M cursor.json
 M next.config.js
 M package-lock.json
 M package.json
 M pages/Otomasyon.tsx
 M pages/StratejiJeneratoru.tsx
 D pages/StratejiJeneratoru_backup.tsx
 M pages/Stratejilerim.tsx
 M pages/_app.tsx
 M pages/api/ai-strategy-generator.ts
 M pages/api/strategy/backtest.ts
 M pages/api/strategy/generate.ts
 M pages/api/strategy/lint.ts
 M pages/api/strategy/optimize.ts
 M pages/api/supervisor.ts
 M pages/api/supervisor/config.ts
 M pages/api/supervisor/stats.ts
 M pages/api/supervisor/toggle.ts
 M pages/index.tsx
 M pages/yardim.tsx
 M services/AIAnalysisService.ts
 M services/BinanceService.ts
 M services/SupervisorAgent.ts
 M tsconfig.json
?? GPT_Backups/
?? apps/
?? components/BacktestChart.tsx
?? components/ConsolePanel.tsx
?? components/ExportButtons.tsx
?? components/ExportExcel.tsx
?? components/MonacoEditor.tsx
?? components/MonacoEditorPro.tsx
?? components/OptimizeHeatmap.tsx
?? components/OptimizeHeatmapFaceted.tsx
?? components/OptimizePanel.tsx
?? components/PerformanceCards.tsx
?? components/StrategyWizard.tsx
?? contexts/
?? docs/
?? lib/
?? packages/
?? pages/api/health.ts
?? pages/api/realtime.ts
?? pages/api/strategy/assistant.ts
?? pages/api/strategy/compile.ts
?? safe-backup.ps1
?? services/Logger.ts
?? services/SupervisorSingleton.ts
?? services/brokers/
?? services/marketdata/
?? services/strategyMachine.ts
?? stores/
?? tsconfig.base.json
?? types/


## 2025-08-10 01:59:47Z
- Build: success
- Commit: eb14ab4
- Changes:
 M apps/web-next/components/OptimizePanel.tsx
 M apps/web-next/components/StrategyLab/StrategyPrompt.tsx
 M apps/web-next/next.config.js
 M apps/web-next/pages/_app.tsx
 M apps/web-next/pages/api/market-data.ts
 M apps/web-next/pages/strategy-lab.tsx
 M apps/web-next/server/supervisor.ts
 M apps/web-next/stores/useStrategyLabStore.ts
 M tsconfig.json
?? apps/web-next/components/StrategyLab/OptimizeSettings.tsx
?? apps/web-next/components/StrategyLab/SaveLoadBar.tsx
?? apps/web-next/components/ThemeToggle.tsx
?? apps/web-next/pages/api/strategy/compile.ts
?? apps/web-next/pages/api/strategy/lint.ts
?? apps/web-next/styles/


## 2025-08-10 02:06:31Z
- Build: success
- Commit: eb14ab4
- Changes:
 M apps/web-next/components/OptimizePanel.tsx
 M apps/web-next/components/StrategyLab/StrategyPrompt.tsx
 M apps/web-next/next.config.js
 M apps/web-next/pages/_app.tsx
 M apps/web-next/pages/api/market-data.ts
 M apps/web-next/pages/strategy-lab.tsx
 M apps/web-next/server/supervisor.ts
 M apps/web-next/stores/useStrategyLabStore.ts
 M docs/PLAN_PROGRESS.md
 M tsconfig.json
?? GPT_Backups/backup_20250810_015947/
?? apps/web-next/components/StrategyLab/OptimizeSettings.tsx
?? apps/web-next/components/StrategyLab/SaveLoadBar.tsx
?? apps/web-next/components/ThemeToggle.tsx
?? apps/web-next/pages/api/strategy/compile.ts
?? apps/web-next/pages/api/strategy/lint.ts
?? apps/web-next/styles/


## 2025-08-10 21:14:21Z
- Build: success
- Commit: eb14ab4
- Changes:
 M apps/web-next/components/Nav.tsx
 M apps/web-next/components/OptimizePanel.tsx
 M apps/web-next/components/StrategyLab/ParameterPanel.tsx
 M apps/web-next/components/StrategyLab/StrategyPrompt.tsx
 M apps/web-next/next.config.js
 M apps/web-next/pages/_app.tsx
 M apps/web-next/pages/api/market-data.ts
 M apps/web-next/pages/index.tsx
 M apps/web-next/pages/strategy-lab.tsx
 M apps/web-next/server/supervisor.ts
 M apps/web-next/stores/useStrategyLabStore.ts
 M components/AIChatPanel.tsx
 M components/BacktestChart.tsx
 M docs/PLAN_PROGRESS.md
 M tailwind.config.js
 M tsconfig.json
?? GPT_Backups/backup_20250810_015947/
?? GPT_Backups/backup_20250810_020631/
?? apps/web-next/components/StrategyLab/OptimizeSettings.tsx
?? apps/web-next/components/StrategyLab/SaveLoadBar.tsx
?? apps/web-next/components/ThemeToggle.tsx
?? apps/web-next/pages/Ayarlar.tsx
?? apps/web-next/pages/PortfoyYonetimi.tsx
?? apps/web-next/pages/StratejiJeneratoru.tsx
?? apps/web-next/pages/Stratejilerim.tsx
?? apps/web-next/pages/api/strategy/compile.ts
?? apps/web-next/pages/api/strategy/lint.ts
?? apps/web-next/styles/


