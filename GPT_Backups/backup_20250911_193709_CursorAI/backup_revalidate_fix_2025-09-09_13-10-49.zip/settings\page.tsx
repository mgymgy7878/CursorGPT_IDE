'use client';

import { useState } from 'react';

export default function SettingsPage() {
  const [risk, setRisk] = useState(0.5);
  return (
    <main className="p-6 space-y-6">
      <h1 className="text-2xl font-semibold">Ayarlar</h1>
      <div className="rounded-xl bg-slate-800/60 p-4 space-y-3">
        <div className="font-medium">Varsayılan Risk Yüzdesi</div>
        <input
          type="range" min={0} max={5} step={0.1}
          value={risk}
          onChange={e => setRisk(Number(e.target.value))}
          className="w-full"
        />
        <div className="text-sm text-slate-400">{risk.toFixed(1)}%</div>
      </div>
    </main>
  );
}
