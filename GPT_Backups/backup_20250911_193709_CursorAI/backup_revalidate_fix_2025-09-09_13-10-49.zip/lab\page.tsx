'use client';

import { useStrategiesStore } from '@/stores/strategiesStore';
import { useState } from 'react';

export default function LabPage() {
  const { addStrategy } = useStrategiesStore();
  const [name, setName] = useState('Yeni Strateji');
  const [code, setCode] = useState('// burada strateji kodu…');

  function handleSave() {
    addStrategy({
      name,
      category: 'Özel',
      description: 'AI Copilot ile oluşturuldu',
      code,
    });
    window.location.href = '/strategies';
  }

  return (
    <main className="p-6 space-y-6">
      <h1 className="text-2xl font-semibold">Strateji Laboratuvarı</h1>

      {/* AI Copilot (stub) */}
      <div className="rounded-xl bg-slate-800/60 p-4">
        <div className="font-medium mb-2">AI Copilot</div>
        <p className="text-sm text-slate-400">
          Prompt'a strateji fikrini yaz, Copilot sana iskelet kodu önersin. (Stub)
        </p>
      </div>

      {/* Editör */}
      <div className="rounded-xl bg-slate-800/60 p-4 space-y-3">
        <input
          className="w-full rounded-lg bg-slate-900/70 p-2"
          value={name}
          onChange={e => setName(e.target.value)}
        />
        <textarea
          className="w-full h-64 rounded-lg bg-slate-900/70 p-2 font-mono"
          value={code}
          onChange={e => setCode(e.target.value)}
        />
        <div className="flex gap-2">
          <button className="btn-secondary">Backtest</button>
          <button className="btn-secondary">Optimizasyon</button>
          <button onClick={handleSave} className="btn-primary ml-auto">Kaydet</button>
        </div>
      </div>
    </main>
  );
}
