'use client';

import { useStrategiesStore } from '@/stores/strategiesStore';

export default function ActiveStrategiesPage() {
  const { running } = useStrategiesStore();
  return (
    <main className="p-6 space-y-6">
      <h1 className="text-2xl font-semibold">Çalışan Stratejiler</h1>
      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-3">
        {running.length === 0 && <div className="text-slate-400">Şu an çalışan strateji yok.</div>}
        {running.map(r => (
          <div key={r.id} className="rounded-xl bg-slate-800/60 p-4 space-y-2">
            <div className="font-medium">{r.name}</div>
            <div className="text-sm text-slate-400">Durum: {r.status}</div>
          </div>
        ))}
      </div>
    </main>
  );
}
