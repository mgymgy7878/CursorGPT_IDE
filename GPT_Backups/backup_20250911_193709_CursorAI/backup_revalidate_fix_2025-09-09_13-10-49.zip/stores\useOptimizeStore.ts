import { create } from "zustand";
import type { OptimizeRequest, OptimizeResult } from "@spark/shared";
import { postJSON } from "@spark/shared";

type State = {
  runId?: string;
  running: boolean;
  progress: { done: number; total: number; pct: number } | null;
  result?: OptimizeResult;
  error?: string;
  start: (req: OptimizeRequest) => Promise<void>;
  reset: () => void;
};

export const useOptimizeStore = create<State>((set) => ({
  running: false, progress: null,
  async start(req) {
    set({ running: true, error: undefined, result: undefined, progress: { done:0, total:0, pct:0 } });
    const runId = Math.random().toString(36).slice(2);
    set({ runId });
    try {
      const data = await postJSON<OptimizeResult>(`/api/strategy/optimize?runId=${runId}`, req);
      set({ result: data, running: false });
    } catch (e: any) {
      set({ error: e?.message ?? 'optimize failed', running: false });
    }
  },
  reset() { set({ runId: undefined, running: false, progress: null, result: undefined, error: undefined }); }
})); 
