export default function PortfolioPage() {
  return (
    <main className="p-6 space-y-6">
      <h1 className="text-2xl font-semibold">Portföy</h1>
      <p className="text-slate-400">Canlı pozisyonlar yakında burada listelenecek.</p>
    </main>
  );
}
